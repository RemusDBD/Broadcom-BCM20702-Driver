
直接把两个文件复制到/lib/firmware/brcm文件夹下

然后重启即可！

